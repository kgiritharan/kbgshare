#!/bin/bash

# Check if "work" folder exists, if not, create it
if [ ! -d "/media/giri/data/ignite/data_dir/work" ]; then
    echo "Creating 'work' directory..."
    mkdir /media/giri/data/ignite/data_dir/work
else
    echo "'work' directory already exists."
fi

# Start Docker Compose in detached mode
docker compose up -d

# Wait for the Ignite container to be fully up
echo "Waiting for Ignite to start..."
sleep 10  # Adjust the sleep time if needed

# Activate the Ignite cluster
echo "Activating Ignite cluster..."
docker compose exec ignite /opt/ignite/apache-ignite/bin/control.sh --set-state ACTIVE --yes

echo "Ignite cluster is now ACTIVE."
